'use client'

import { useState, useEffect } from 'react'
import { defaultStats } from '@/lib/fakeData'

interface DeployPanelProps {
  onDeploy: () => void
  isDeploying: boolean
}

export default function DeployPanel({ onDeploy, isDeploying }: DeployPanelProps) {
  const [progress, setProgress] = useState(defaultStats.progress)
  const [logs, setLogs] = useState<string[]>([])

  useEffect(() => {
    if (isDeploying) {
      setProgress(defaultStats.progress)
      setLogs([])
      const startTime = Date.now()
      const duration = 5000 + Math.random() * 1000 // 5-6 seconds
      const startProgress = defaultStats.progress
      const targetProgress = 100
      const progressRange = targetProgress - startProgress
      
      const interval = setInterval(() => {
        const elapsed = Date.now() - startTime
        const progressRatio = Math.min(elapsed / duration, 1)
        const newProgress = startProgress + (progressRange * progressRatio)
        
        setProgress(newProgress)
        
        if (progressRatio >= 1) {
          clearInterval(interval)
          setLogs((prevLogs) => [...prevLogs, `[${new Date().toLocaleTimeString()}] Deploy completed successfully`])
        }
      }, 50) // Update every 50ms for smooth animation
      
      return () => clearInterval(interval)
    }
  }, [isDeploying])

  const handleDeploy = () => {
    onDeploy()
  }

  return (
    <div className="w-full max-w-[390px] mx-auto px-4 mb-4">
      <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/60 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50">
        <h3 className="text-lg font-semibold text-white mb-4">Progress</h3>
        
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-300">{Math.round(progress)}%</span>
            <span className="text-xs text-gray-400">Deploying...</span>
          </div>
          <div className="w-full h-3 bg-gray-800/50 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#6B3CFF] to-[#8B5FFF] rounded-full transition-all duration-300 shadow-lg shadow-[#6B3CFF]/50"
              style={{ width: `${Math.min(progress, 100)}%` }}
            ></div>
          </div>
        </div>

        {logs.length > 0 && (
          <div className="mb-4 p-3 bg-black/40 rounded-xl border border-gray-700/30">
            <div className="space-y-1">
              {logs.map((log, index) => (
                <p key={index} className="text-xs text-green-400 font-mono">{log}</p>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={handleDeploy}
          disabled={isDeploying}
          className={`w-full py-3 rounded-xl font-semibold transition-all duration-200 ${
            isDeploying
              ? 'bg-gray-700/50 text-gray-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-[#6B3CFF] to-[#8B5FFF] text-white hover:shadow-lg hover:shadow-[#6B3CFF]/50 active:scale-95'
          }`}
        >
          {isDeploying ? 'Deploying...' : 'Deploy'}
        </button>
      </div>
    </div>
  )
}

