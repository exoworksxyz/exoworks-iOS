'use client'

import { useState, useEffect } from 'react'
import { generateFakeTransactions } from '@/lib/fakeData'

interface Transaction {
  id: number
  hash: string
  status: 'pending' | 'confirmed'
  timestamp: number
}

interface TransactionsDrawerProps {
  isOpen: boolean
  onToggle: () => void
}

export default function TransactionsDrawer({ isOpen, onToggle }: TransactionsDrawerProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([])

  useEffect(() => {
    if (isOpen && transactions.length === 0) {
      setTransactions(generateFakeTransactions(5))
    }
  }, [isOpen, transactions.length])

  const formatHash = (hash: string) => {
    return `${hash.slice(0, 8)}...${hash.slice(-8)}`
  }

  return (
    <div className="w-full max-w-[390px] mx-auto px-4 mb-4">
      <button
        onClick={onToggle}
        className="w-full bg-gradient-to-br from-gray-900/80 to-gray-800/60 backdrop-blur-xl rounded-2xl p-4 border border-gray-700/50 hover:border-gray-600/50 transition-all duration-200"
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Solana Transactions</h3>
          <span className="text-sm text-gray-400">{isOpen ? '▼' : '▶'}</span>
        </div>
      </button>

      {isOpen && (
        <div className="mt-2 bg-gradient-to-br from-gray-900/60 to-gray-800/40 backdrop-blur-xl rounded-2xl p-4 border border-gray-700/30 space-y-3">
          {transactions.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-4">No transactions yet</p>
          ) : (
            transactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-3 bg-black/30 rounded-xl border border-gray-700/20"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-gray-400 font-mono truncate">{formatHash(tx.hash)}</p>
                </div>
                <div className="ml-3">
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      tx.status === 'confirmed'
                        ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                        : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                    }`}
                  >
                    {tx.status === 'confirmed' ? 'Confirmed' : 'Pending'}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}

