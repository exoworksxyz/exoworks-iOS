export const defaultStats = {
  tps: 2350,
  cpu: 14,
  ram: 5.7,
  progress: 72,
}

export const generateFakeTxHash = (): string => {
  const chars = '0123456789abcdef'
  return Array.from({ length: 64 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
}

export const generateFakeTransactions = (count: number = 5) => {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    hash: generateFakeTxHash(),
    status: i < 2 ? 'pending' : 'confirmed',
    timestamp: Date.now() - (count - i) * 10000,
  }))
}

export const features = [
  { id: 1, name: 'Load Surge', description: 'Simulate high traffic scenarios' },
  { id: 2, name: 'Branch Workflow', description: 'Create parallel execution paths' },
  { id: 3, name: 'Replay Deploy', description: 'Replay previous deployments' },
  { id: 4, name: 'Chaos Mode', description: 'Test system resilience' },
]

export const workflows = [
  { id: 1, name: 'Workflow 1' },
  { id: 2, name: 'Workflow 2' },
  { id: 3, name: 'Workflow 3' },
]

