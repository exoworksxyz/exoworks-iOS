'use client'

import { useState } from 'react'
import StatusStrip from '@/components/StatusStrip'
import WorkspaceCard from '@/components/WorkspaceCard'
import WorkflowStack from '@/components/WorkflowStack'
import FeatureLab from '@/components/FeatureLab'
import DeployPanel from '@/components/DeployPanel'
import TransactionsDrawer from '@/components/TransactionsDrawer'
import HomeIndicator from '@/components/HomeIndicator'

export default function Home() {
  const [systemStatus, setSystemStatus] = useState<string>('System ready')
  const [isDeploying, setIsDeploying] = useState(false)
  const [isTransactionsOpen, setIsTransactionsOpen] = useState(false)

  const handleFeatureSelect = (name: string) => {
    setSystemStatus(`${name} activated`)
    setTimeout(() => setSystemStatus('System ready'), 3000)
  }

  const handleDeploy = () => {
    setIsDeploying(true)
    setIsTransactionsOpen(true)
    setTimeout(() => {
      setIsDeploying(false)
    }, 6000) // Allow time for animation to complete
  }

  return (
    <main className="min-h-screen w-full bg-black flex flex-col items-center justify-start pt-2 pb-8">
      <StatusStrip />
      
      <div className="w-full max-w-[390px] flex flex-col items-center">
        <WorkspaceCard />
        <WorkflowStack />
        <FeatureLab onFeatureSelect={handleFeatureSelect} />
        
        <div className="w-full max-w-[390px] mx-auto px-4 mb-4">
          <div className="bg-gray-900/40 backdrop-blur-sm rounded-xl p-3 border border-gray-700/30">
            <p className="text-sm text-center text-gray-300">{systemStatus}</p>
          </div>
        </div>

        <DeployPanel onDeploy={handleDeploy} isDeploying={isDeploying} />
        <TransactionsDrawer isOpen={isTransactionsOpen} onToggle={() => setIsTransactionsOpen(!isTransactionsOpen)} />
        <HomeIndicator />
      </div>
    </main>
  )
}

