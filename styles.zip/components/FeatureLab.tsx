'use client'

import { useState } from 'react'
import { features } from '@/lib/fakeData'

export default function FeatureLab({ onFeatureSelect }: { onFeatureSelect: (name: string) => void }) {
  const [selectedId, setSelectedId] = useState<number | null>(null)

  const handleSelect = (id: number, name: string) => {
    setSelectedId(id)
    onFeatureSelect(name)
  }

  return (
    <div className="w-full max-w-[390px] mx-auto px-4 mb-4">
      <h3 className="text-lg font-semibold text-white mb-3 px-1">Feature Lab</h3>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {features.map((feature) => (
          <button
            key={feature.id}
            onClick={() => handleSelect(feature.id, feature.name)}
            className={`flex-shrink-0 w-32 bg-gradient-to-br from-gray-900/80 to-gray-800/60 backdrop-blur-xl rounded-2xl p-4 border transition-all duration-200 ${
              selectedId === feature.id
                ? 'border-[#FFB547] shadow-lg shadow-[#FFB547]/30 scale-105'
                : 'border-gray-700/50 hover:border-gray-600/50'
            }`}
          >
            <div className="text-center">
              <div className={`w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center ${
                selectedId === feature.id
                  ? 'bg-gradient-to-br from-[#FFB547] to-[#FFC966]'
                  : 'bg-gray-700/50'
              }`}>
                <span className="text-white font-bold text-lg">{feature.id}</span>
              </div>
              <p className="text-xs text-white font-medium">{feature.name}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

