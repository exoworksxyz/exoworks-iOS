'use client'

import { useState } from 'react'
import { workflows } from '@/lib/fakeData'

export default function WorkflowStack() {
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [toast, setToast] = useState<string | null>(null)

  const handleSelect = (id: number, name: string) => {
    setSelectedId(id)
    setToast(`Workflow ${id} selected`)
    setTimeout(() => setToast(null), 2000)
  }

  return (
    <div className="w-full max-w-[390px] mx-auto px-4 mb-4 relative">
      {toast && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-black/80 backdrop-blur-md px-4 py-2 rounded-full border border-[#6B3CFF]/50 shadow-lg">
          <span className="text-sm text-white">{toast}</span>
        </div>
      )}
      <div className="space-y-0">
        {workflows.map((workflow, index) => (
          <div key={workflow.id} className="relative">
            {index > 0 && (
              <div className="absolute left-8 top-0 w-0.5 h-4 bg-gradient-to-b from-[#6B3CFF]/50 to-transparent -translate-y-full"></div>
            )}
            <button
              onClick={() => handleSelect(workflow.id, workflow.name)}
              className={`w-full bg-gradient-to-br from-gray-900/80 to-gray-800/60 backdrop-blur-xl rounded-2xl p-4 border transition-all duration-200 ${
                selectedId === workflow.id
                  ? 'border-[#6B3CFF] shadow-lg shadow-[#6B3CFF]/30 scale-[1.02]'
                  : 'border-gray-700/50 hover:border-gray-600/50'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  selectedId === workflow.id
                    ? 'bg-gradient-to-br from-[#6B3CFF] to-[#8B5FFF]'
                    : 'bg-gray-700/50'
                }`}>
                  <span className="text-white font-semibold">{workflow.id}</span>
                </div>
                <span className="text-white font-medium">{workflow.name}</span>
              </div>
            </button>
            {index < workflows.length - 1 && (
              <div className="w-0.5 h-4 bg-gradient-to-b from-transparent to-[#6B3CFF]/50 mx-auto"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

