'use client'

import { useEffect } from 'react'

export default function CapacitorInit() {
  useEffect(() => {
    // Initialize Capacitor plugins on client side only
    if (typeof window !== 'undefined') {
      import('@capacitor/core').then(({ Capacitor }) => {
        if (Capacitor.isNativePlatform()) {
          // Initialize native plugins
          import('@capacitor/app').then(({ App }) => {
            App.addListener('appStateChange', ({ isActive }) => {
              console.log('App state changed. Is active?', isActive)
            })
          })

          import('@capacitor/splash-screen').then(({ SplashScreen }) => {
            SplashScreen.hide()
          })

          import('@capacitor/status-bar').then(({ StatusBar }) => {
            StatusBar.setStyle({ style: 'dark' })
            StatusBar.setBackgroundColor({ color: '#000000' })
          })
        }
      })
    }
  }, [])

  return null
}


