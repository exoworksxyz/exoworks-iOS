'use client'

export default function StatusStrip() {
  return (
    <div className="w-full max-w-[390px] px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
        <span className="text-sm text-gray-300">Connected</span>
      </div>
      <span className="text-xs text-gray-400 font-medium">ExoWorks</span>
    </div>
  )
}

