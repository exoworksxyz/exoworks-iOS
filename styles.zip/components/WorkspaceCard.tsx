'use client'

export default function WorkspaceCard() {
  return (
    <div className="w-full max-w-[390px] mx-auto px-4 mb-4">
      <div className="bg-gradient-to-br from-[#6B3CFF]/20 to-[#6B3CFF]/10 backdrop-blur-xl rounded-3xl p-6 border border-[#6B3CFF]/30 shadow-lg shadow-[#6B3CFF]/20">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6B3CFF] to-[#8B5FFF] flex items-center justify-center shadow-lg shadow-[#6B3CFF]/50">
            <span className="text-2xl font-bold text-white">E</span>
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-white mb-1">Workspace</h2>
            <p className="text-sm text-gray-300">Solana Mainnet Alpha</p>
          </div>
        </div>
      </div>
    </div>
  )
}

