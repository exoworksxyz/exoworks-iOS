'use client'

export default function HomeIndicator() {
  return (
    <div className="w-full max-w-[390px] mx-auto px-4 pb-4">
      <div className="flex justify-center">
        <div className="w-32 h-1 bg-white/30 rounded-full"></div>
      </div>
    </div>
  )
}

